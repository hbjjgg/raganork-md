// Made with ❤ by SKL11
// Module({pattern: 'status_sender ?(.*)', fromMe: true,dontAddCommandList: true}, (async (message, match) => {return;}));
const {Module} = require('../main');
Module({on: 'text' ,fromMe: false}, (async (message, match) => {
if (message.fromMe || !message.reply_message || message.quoted.key.remoteJid !== 'status@broadcast') return;
var sends = ["send","snd","sent","snt","Send","Snd","Sent","Daw","Da","Da Vai","Dao","Send Me","da vai","Send Kor","Send kor","Send Kor Vai"]
for (any in sends){
if (message.message.includes(sends[any])) {
return await message.forwardMessage(message.jid, message.quoted,{contextInfo:{ isForwarded: false}});
}
}
}));